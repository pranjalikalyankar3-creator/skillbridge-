import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth);

const learningPath = [
  { id: 'html-css', title: 'Web foundations', detail: 'HTML, CSS, responsive layouts', duration: '1–2 weeks', level: 'Beginner' },
  { id: 'javascript', title: 'JavaScript essentials', detail: 'Variables, functions, arrays, async basics', duration: '2–3 weeks', level: 'Beginner' },
  { id: 'react', title: 'Build with React', detail: 'Components, state, forms, routing', duration: '2–3 weeks', level: 'Intermediate' },
  { id: 'api', title: 'Connect a real API', detail: 'Express, REST, MongoDB, authentication', duration: '2–3 weeks', level: 'Intermediate' }
];
const opportunities = [
  { id: 'portfolio', title: 'Build a portfolio project', type: 'Project', detail: 'Create a small app that solves a real student problem.', tags: ['Web development', 'Portfolio'] },
  { id: 'hackathon', title: 'Join a student hackathon', type: 'Event', detail: 'Practice teamwork, pitching, and rapid prototyping.', tags: ['Teamwork', 'Innovation'] },
  { id: 'internship', title: 'Prepare for internships', type: 'Career', detail: 'Polish your resume, GitHub profile, and interview basics.', tags: ['Career readiness', 'Communication'] }
];

router.get('/', (req, res) => {
  const user = req.user;
  res.json({
    user: { id: user._id, name: user.name, email: user.email, education: user.education, interests: user.interests, skills: user.skills, completedLessons: user.completedLessons },
    stats: { skillsTracked: user.skills.length, lessonsCompleted: user.completedLessons, roadmapSteps: learningPath.length },
    learningPath,
    opportunities
  });
});

router.patch('/profile', async (req, res, next) => {
  try {
    const allowed = {};
    if (typeof req.body.education === 'string') allowed.education = req.body.education.slice(0, 120);
    if (Array.isArray(req.body.interests)) allowed.interests = req.body.interests.slice(0, 10).map((x) => String(x).slice(0, 40));
    if (Array.isArray(req.body.skills)) allowed.skills = [...new Set(req.body.skills.slice(0, 30).map((x) => String(x).trim().slice(0, 40)).filter(Boolean))];
    const user = req.user;
    Object.assign(user, allowed);
    await user.save();
    res.json({ user: { id: user._id, name: user.name, email: user.email, education: user.education, interests: user.interests, skills: user.skills, completedLessons: user.completedLessons } });
  } catch (error) { next(error); }
});

router.post('/lessons/:id/complete', async (req, res, next) => {
  try {
    const validIds = new Set(learningPath.map((item) => item.id));
    if (!validIds.has(req.params.id)) return res.status(404).json({ message: 'Learning step not found.' });
    req.user.completedLessons = Math.min(learningPath.length, req.user.completedLessons + 1);
    await req.user.save();
    res.json({ completedLessons: req.user.completedLessons });
  } catch (error) { next(error); }
});

export default router;
