# SkillBridge MVP

A starter full-stack student skill-development portal built with React, Vite, Express, MongoDB, and JWT authentication.

## Included
- Student registration and login
- Password hashing with bcrypt
- JWT-protected API routes
- Student profile and dashboard
- Skill list, learning roadmap, and opportunity catalogue (starter/sample data)
- Health and database-health endpoints
- Centralized error handling and basic input validation

## Requirements
- Node.js 20 or newer
- npm
- MongoDB local instance or MongoDB Atlas connection string

## Run locally
1. Open a terminal in this folder.
2. Install dependencies:
   ```bash
   npm run install:all
   ```
3. Copy `server/.env.example` to `server/.env` and set `MONGODB_URI` and a long random `JWT_SECRET`.
4. Start both apps:
   ```bash
   npm run dev
   ```
5. Open `http://localhost:5173`.

The API runs on `http://localhost:5000`. Check `http://localhost:5000/api/health` and `http://localhost:5000/api/health/db`.

## Production deployment notes
- Deploy the `server` folder as a Node service and set `MONGODB_URI`, `JWT_SECRET`, `CLIENT_ORIGIN`, and `PORT` in the hosting dashboard.
- Deploy the `client` folder as a static Vite site. Set `VITE_API_BASE_URL` to the deployed backend origin, without a trailing `/` (example: `https://your-api.example.com`). Rebuild after setting it.
- Add the frontend's exact deployed origin to `CLIENT_ORIGIN` on the backend.
- In MongoDB Atlas, allow network access only as appropriate for your host and use a database user with a strong password.
- Use HTTPS in production. Never commit `.env` files or share JWT secrets/database credentials.
- This is an MVP starter, not a fully audited production system. Before public launch, add rate limiting, email verification/password reset, stronger monitoring, automated tests, privacy review, and challenge-specific content.

## Troubleshooting
- `API unavailable`: verify backend is running and `VITE_API_BASE_URL` is correct.
- Database health returns 503: verify `MONGODB_URI`, Atlas network access, and server logs.
- CORS error: set `CLIENT_ORIGIN` to the exact frontend origin and restart the backend.
- Dashboard request returns 401: sign in again; the browser stores the JWT in localStorage for this demo.
