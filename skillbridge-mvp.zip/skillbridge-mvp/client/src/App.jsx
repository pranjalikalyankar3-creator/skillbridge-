import { useEffect, useMemo, useState } from 'react';
import { Activity, ArrowRight, BookOpen, BriefcaseBusiness, Check, ChevronRight, GraduationCap, LayoutDashboard, LogOut, Menu, Plus, ShieldCheck, Sparkles, Target, TrendingUp, Users, X } from 'lucide-react';

const API_BASE = (import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000').replace(/\/$/, '');

async function api(path, { token, ...options } = {}) {
  let response;
  try {
    response = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(options.headers || {}) }
    });
  } catch {
    throw new Error(`Cannot reach the SkillBridge API at ${API_BASE}. Check that the backend is running and the API URL is correct.`);
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || `Request failed (${response.status}).`);
  return data;
}

const initials = (name = 'Student') => name.split(' ').filter(Boolean).slice(0, 2).map((s) => s[0]).join('').toUpperCase();

function AuthScreen({ onAuth }) {
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const update = (key) => (event) => setForm((current) => ({ ...current, [key]: event.target.value }));
  async function submit(event) {
    event.preventDefault(); setError(''); setBusy(true);
    try {
      const result = await api(`/api/auth/${mode}`, { method: 'POST', body: JSON.stringify(form) });
      onAuth(result);
    } catch (e) { setError(e.message); } finally { setBusy(false); }
  }
  return <main className="auth-layout">
    <section className="auth-story">
      <a className="brand brand-light" href="#home"><span className="brand-mark"><GraduationCap size={22}/></span> SkillBridge</a>
      <div className="story-copy"><span className="eyebrow light-eyebrow"><Sparkles size={14}/> YOUR FUTURE, IN PROGRESS</span><h1>Small steps.<br/><em>Real momentum.</em></h1><p>Build practical skills, find your next learning opportunity, and make your career goals feel closer every day.</p>
        <div className="story-stat-row"><div className="story-stat"><strong>01</strong><span>Find your direction</span></div><div className="story-stat"><strong>02</strong><span>Learn by doing</span></div><div className="story-stat"><strong>03</strong><span>Move forward</span></div></div>
      </div><div className="story-bottom"><ShieldCheck size={16}/> Your learning journey, organised in one place.</div>
      <div className="orb orb-one"/><div className="orb orb-two"/>
    </section>
    <section className="auth-panel"><div className="auth-box"><div className="mobile-brand"><span className="brand-mark"><GraduationCap size={20}/></span> SkillBridge</div><span className="eyebrow">GET STARTED</span><h2>{mode === 'login' ? 'Welcome back' : 'Create your account'}</h2><p className="muted">{mode === 'login' ? 'Pick up where your learning journey left off.' : 'Your next opportunity starts with one step.'}</p>
      <form onSubmit={submit} className="auth-form">{mode === 'register' && <label>Full name<input autoComplete="name" value={form.name} onChange={update('name')} placeholder="e.g. Aditi Sharma" required minLength={2}/></label>}<label>Email address<input type="email" autoComplete="email" value={form.email} onChange={update('email')} placeholder="you@example.com" required/></label><label>Password<input type="password" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} value={form.password} onChange={update('password')} placeholder="At least 8 characters" required minLength={8}/></label>
        {error && <div className="error-box" role="alert">{error}</div>}<button className="btn btn-primary btn-wide" disabled={busy}>{busy ? 'Please wait…' : mode === 'login' ? 'Sign in' : 'Create account'} <ArrowRight size={17}/></button></form>
      <p className="switch-auth">{mode === 'login' ? 'New to SkillBridge?' : 'Already have an account?'} <button onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setError(''); }} className="text-button">{mode === 'login' ? 'Create an account' : 'Sign in'}</button></p><p className="privacy-note"><ShieldCheck size={14}/> Your account details are protected.</p>
    </div></section>
  </main>;
}

function App() {
  const [session, setSession] = useState(() => ({ token: localStorage.getItem('skillbridge_token'), user: null }));
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [tab, setTab] = useState('overview');
  const [mobileNav, setMobileNav] = useState(false);
  const [skillInput, setSkillInput] = useState('');
  const [saving, setSaving] = useState(false);

  async function loadDashboard(token) {
    setLoading(true); setError('');
    try { const result = await api('/api/dashboard', { token }); setData(result); setSession((s) => ({ ...s, user: result.user })); }
    catch (e) { setError(e.message); if (/session|sign in|account not found/i.test(e.message)) logout(); }
    finally { setLoading(false); }
  }
  useEffect(() => { if (session.token) loadDashboard(session.token); }, [session.token]);
  function login(result) { localStorage.setItem('skillbridge_token', result.token); setSession({ token: result.token, user: result.user }); }
  function logout() { localStorage.removeItem('skillbridge_token'); setSession({ token: null, user: null }); setData(null); setError(''); }

  async function saveSkills(event) {
    event.preventDefault();
    const skill = skillInput.trim(); if (!skill || !data) return;
    const skills = [...new Set([...(data.user.skills || []), skill])];
    setSaving(true); setError('');
    try { const result = await api('/api/dashboard/profile', { token: session.token, method: 'PATCH', body: JSON.stringify({ skills }) }); setData((d) => ({ ...d, user: { ...d.user, ...result.user }, stats: { ...d.stats, skillsTracked: result.user.skills.length } })); setSkillInput(''); }
    catch (e) { setError(e.message); } finally { setSaving(false); }
  }
  async function completeLesson(id) {
    setError('');
    try { const result = await api(`/api/dashboard/lessons/${id}/complete`, { token: session.token, method: 'POST', body: '{}' }); setData((d) => ({ ...d, user: { ...d.user, completedLessons: result.completedLessons }, stats: { ...d.stats, lessonsCompleted: result.completedLessons } })); }
    catch (e) { setError(e.message); }
  }

  if (!session.token) return <AuthScreen onAuth={login}/>;
  const user = data?.user || session.user || { name: 'Student', skills: [] };
  const nav = [{ id: 'overview', label: 'Overview', icon: LayoutDashboard }, { id: 'roadmap', label: 'Learning roadmap', icon: BookOpen }, { id: 'opportunities', label: 'Opportunities', icon: BriefcaseBusiness }, { id: 'skills', label: 'My skills', icon: Target }];
  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav ? 'sidebar-open' : ''}`}><div className="sidebar-top"><a className="brand" href="#home"><span className="brand-mark"><GraduationCap size={22}/></span> SkillBridge</a><button className="icon-btn sidebar-close" onClick={() => setMobileNav(false)} aria-label="Close menu"><X size={19}/></button></div><div className="workspace-label">YOUR WORKSPACE</div><nav className="side-nav">{nav.map(({ id, label, icon: Icon }) => <button key={id} onClick={() => { setTab(id); setMobileNav(false); }} className={`nav-item ${tab === id ? 'active' : ''}`}><Icon size={18}/><span>{label}</span>{tab === id && <ChevronRight size={15} className="nav-arrow"/>}</button>)}</nav><div className="sidebar-spacer"/><div className="sidebar-tip"><div className="tip-icon"><Sparkles size={17}/></div><strong>Keep your momentum</strong><p>Progress comes from consistent, small steps.</p><button onClick={() => setTab('roadmap')}>View my roadmap <ArrowRight size={14}/></button></div><div className="sidebar-user"><div className="avatar">{initials(user.name)}</div><div className="user-meta"><strong>{user.name}</strong><span>{user.email}</span></div><button className="icon-btn logout-btn" onClick={logout} title="Sign out" aria-label="Sign out"><LogOut size={17}/></button></div></aside>
    {mobileNav && <button className="nav-backdrop" aria-label="Close navigation" onClick={() => setMobileNav(false)}/>}
    <main className="main-area"><header className="topbar"><button className="icon-btn mobile-menu" onClick={() => setMobileNav(true)} aria-label="Open menu"><Menu size={21}/></button><div className="breadcrumb">Workspace <ChevronRight size={14}/> <strong>{nav.find((n) => n.id === tab)?.label || 'Overview'}</strong></div><div className="topbar-right"><span className="status-dot"/> <span>Learning mode</span><div className="avatar avatar-small">{initials(user.name)}</div></div></header>
      <div className="page-content">{error && <div className="error-banner" role="alert"><span>{error}</span><button onClick={() => session.token && loadDashboard(session.token)}>Retry</button><button className="icon-btn" onClick={() => setError('')} aria-label="Dismiss error"><X size={16}/></button></div>}
        {loading && !data ? <div className="loading-card"><div className="spinner"/><strong>Loading your dashboard…</strong><span>Connecting to your learning space</span></div> : !data ? <div className="empty-state"><Activity size={28}/><h2>We couldn't load your dashboard</h2><p>Check your connection, then retry. If this keeps happening, confirm the API URL and backend logs.</p><button className="btn btn-primary" onClick={() => loadDashboard(session.token)}>Try again <ArrowRight size={16}/></button><button className="text-button" onClick={logout}>Sign out</button></div> : <>
          {tab === 'overview' && <Overview data={data} onNavigate={setTab} onComplete={completeLesson} onAddSkill={() => setTab('skills')}/>}
          {tab === 'roadmap' && <Roadmap data={data} onComplete={completeLesson}/>}
          {tab === 'opportunities' && <Opportunities data={data}/>}
          {tab === 'skills' && <section className="page-section"><div className="page-heading"><div><span className="eyebrow">YOUR FOUNDATION</span><h1>My skills</h1><p>Keep track of the skills you're practising and building.</p></div><span className="heading-icon"><Target size={23}/></span></div><div className="panel skills-panel"><h3>Skills I'm building</h3><p className="muted">Add a skill to personalise your learning profile.</p><div className="skill-chips">{(user.skills || []).map((skill) => <span className="skill-chip" key={skill}>{skill}<Check size={13}/></span>)}{!user.skills?.length && <span className="muted small">No skills added yet. Start with one below.</span>}</div><form className="add-skill-form" onSubmit={saveSkills}><input value={skillInput} onChange={(e) => setSkillInput(e.target.value)} placeholder="e.g. React, communication, Python" maxLength={40}/><button className="btn btn-primary" disabled={!skillInput.trim() || saving}><Plus size={16}/> Add skill</button></form></div><div className="note-card"><Sparkles size={19}/><div><strong>Tip: choose skills you can demonstrate</strong><p>A small project, certificate, or practical exercise makes a skill easier to show to mentors and employers.</p></div></div></section>}
        </>}
        <footer className="footer"><span>SkillBridge <span className="footer-dot">•</span> Learn something. Build something.</span><span>Student skill development MVP</span></footer>
      </div></main>
  </div>;
}

function Overview({ data, onNavigate, onComplete, onAddSkill }) {
  const user = data.user;
  const progress = Math.min(100, Math.round((data.stats.lessonsCompleted / Math.max(data.stats.roadmapSteps, 1)) * 100));
  const firstName = user.name?.trim().split(/\s+/)[0] || 'there';
  return <section className="page-section"><div className="welcome-row"><div><span className="eyebrow">YOUR LEARNING SPACE</span><h1>Good to see you, {firstName}<span className="wave">✳</span></h1><p>Every skill you build opens a new door. Here's your next step.</p></div><div className="date-pill"><span className="date-pill-dot"/> Your journey is active</div></div>
    <div className="hero-card"><div className="hero-copy"><span className="hero-tag"><Sparkles size={13}/> YOUR NEXT CHAPTER</span><h2>Turn your curiosity<br/>into <em>real-world skills.</em></h2><p>Follow your roadmap, track what you're learning, and take one practical step today.</p><button className="btn btn-white" onClick={() => onNavigate('roadmap')}>Continue learning <ArrowRight size={16}/></button></div><div className="hero-art"><div className="art-ring ring-one"/><div className="art-ring ring-two"/><div className="art-card art-card-main"><div className="art-card-top"><span className="art-dot"/><span className="art-dot"/><span className="art-dot"/></div><div className="art-cap"><GraduationCap size={35}/></div><div className="art-line long"/><div className="art-line medium"/><div className="art-progress"><span/></div><div className="art-mini-row"><span/><span/><span/></div></div><div className="float-badge float-badge-one"><Check size={14}/> Keep going!</div><div className="float-badge float-badge-two"><TrendingUp size={15}/> Growth in progress</div></div></div>
    <div className="stats-grid"><StatCard icon={Target} label="Skills tracked" value={data.stats.skillsTracked} detail="Your growing toolkit" tone="violet"/><StatCard icon={BookOpen} label="Lessons completed" value={data.stats.lessonsCompleted} detail="Steps taken forward" tone="blue"/><StatCard icon={Activity} label="Roadmap progress" value={`${progress}%`} detail="Keep building momentum" tone="mint"/></div>
    <div className="content-grid"><div className="panel roadmap-preview"><div className="panel-heading"><div><span className="eyebrow">YOUR PATH</span><h3>Learning roadmap</h3></div><button className="link-button" onClick={() => onNavigate('roadmap')}>View all <ArrowRight size={14}/></button></div><p className="muted panel-intro">A simple path from foundations to building your own app.</p><div className="roadmap-mini">{data.learningPath.slice(0, 3).map((item, index) => <div className="mini-step" key={item.id}><div className={`step-number ${index < data.stats.lessonsCompleted ? 'step-done' : ''}`}>{index < data.stats.lessonsCompleted ? <Check size={14}/> : `0${index + 1}`}</div><div className="mini-step-copy"><strong>{item.title}</strong><span>{item.duration} <span className="footer-dot">•</span> {item.level}</span></div><ChevronRight size={16} className="step-chevron"/></div>)}</div><button className="btn btn-outline btn-wide" onClick={() => onNavigate('roadmap')}>Open learning roadmap <ArrowRight size={15}/></button></div>
      <div className="right-stack"><div className="panel skills-preview"><div className="panel-heading"><div><span className="eyebrow">YOUR TOOLKIT</span><h3>Skills I'm building</h3></div><button className="icon-btn soft-icon" onClick={onAddSkill} aria-label="Add a skill"><Plus size={18}/></button></div>{user.skills?.length ? <div className="skill-chips">{user.skills.slice(0, 6).map((s) => <span className="skill-chip" key={s}>{s}</span>)}</div> : <div className="skills-empty"><div className="empty-skill-icon"><Target size={20}/></div><p>Your skills list starts with one small step.</p><button className="link-button" onClick={onAddSkill}>Add your first skill <ArrowRight size={14}/></button></div>}</div><div className="opportunity-teaser"><div className="teaser-icon"><BriefcaseBusiness size={19}/></div><div><strong>Explore what’s next</strong><p>Find projects and career-building activities.</p><button className="link-button" onClick={() => onNavigate('opportunities')}>Explore opportunities <ArrowRight size={14}/></button></div></div></div></div>
  </section>;
}

function StatCard({ icon: Icon, label, value, detail, tone }) { return <div className="stat-card"><div className={`stat-icon ${tone}`}><Icon size={19}/></div><div className="stat-label">{label}</div><div className="stat-value">{value}</div><div className="stat-detail">{detail}</div></div>; }

function Roadmap({ data, onComplete }) {
  const completed = data.stats.lessonsCompleted;
  return <section className="page-section"><div className="page-heading"><div><span className="eyebrow">LEARN BY BUILDING</span><h1>Your learning roadmap</h1><p>Move from the basics to building and connecting a real web app.</p></div><span className="heading-icon"><BookOpen size={23}/></span></div><div className="roadmap-summary panel"><div><span className="muted small">YOUR PROGRESS</span><h3>{completed} of {data.learningPath.length} learning steps completed</h3></div><div className="progress-track"><span style={{ width: `${Math.min(100, completed / data.learningPath.length * 100)}%` }}/></div></div><div className="roadmap-list">{data.learningPath.map((item, index) => { const done = index < completed; const current = index === completed && !done; return <article className={`roadmap-card ${current ? 'roadmap-current' : ''}`} key={item.id}><div className={`roadmap-index ${done ? 'index-done' : current ? 'index-current' : ''}`}>{done ? <Check size={18}/> : `0${index + 1}`}</div><div className="roadmap-card-body"><div className="roadmap-meta"><span className="level-pill">{item.level}</span><span>{item.duration}</span></div><h3>{item.title}</h3><p>{item.detail}</p>{current && <div className="current-label"><span/> UP NEXT</div>}</div><div className="roadmap-card-action">{done ? <span className="completed-label"><Check size={14}/> Completed</span> : <button className={`btn ${current ? 'btn-primary' : 'btn-outline'}`} onClick={() => onComplete(item.id)}>{current ? 'Mark complete' : 'Complete step'} <ArrowRight size={15}/></button>}</div></article>; })}</div><div className="note-card"><Sparkles size={19}/><div><strong>Make it practical</strong><p>For each step, create a tiny project or write down what you learned. Progress is more useful when you can demonstrate it.</p></div></div></section>;
}

function Opportunities({ data }) { return <section className="page-section"><div className="page-heading"><div><span className="eyebrow">MAKE YOUR SKILLS COUNT</span><h1>Opportunities to explore</h1><p>Starter ideas to help you practise, collaborate, and prepare for your next step.</p></div><span className="heading-icon"><BriefcaseBusiness size={23}/></span></div><div className="opportunity-grid">{data.opportunities.map((item, index) => <article className="opportunity-card" key={item.id}><div className={`opportunity-icon op-${index}`}><BriefcaseBusiness size={21}/></div><span className="opportunity-type">{item.type}</span><h3>{item.title}</h3><p>{item.detail}</p><div className="opportunity-tags">{item.tags.map((tag) => <span key={tag}>{tag}</span>)}</div><div className="opportunity-footer"><span>Suggested next step</span><ArrowRight size={16}/></div></article>)}</div><div className="note-card"><Users size={19}/><div><strong>Choose opportunities carefully</strong><p>These are starter suggestions, not live listings or verified vacancies. Check official sources before applying to any real program.</p></div></div></section>; }

export default App;
