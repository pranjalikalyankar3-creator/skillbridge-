SkillBridge mobile-friendly demo

Open index.html in a browser. The website is responsive and includes a dashboard, learning roadmap, sample opportunities, and editable profile.

Important: this is a frontend demo only. It does not provide real online accounts, a backend API, shared database, live vacancies, or hosting. Profile/progress are stored only in the browser on this device. Do not enter passwords or sensitive personal data.
